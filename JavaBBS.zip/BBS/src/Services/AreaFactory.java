package Services;

public interface AreaFactory {
    void createArea();
}
