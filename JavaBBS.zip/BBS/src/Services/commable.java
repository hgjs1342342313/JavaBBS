package Services;
import Entity.comment;
import Entity.Person;
public interface commable {
    void comm(comment c);
}
