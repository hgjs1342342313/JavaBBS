package Services;
import Entity.Person;
import Entity.poster;
public interface Postable {
    void post(poster psr);
}
