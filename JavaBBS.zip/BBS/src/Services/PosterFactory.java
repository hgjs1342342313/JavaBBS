package Services;
import Entity.poster;
public interface PosterFactory {
    void createNewPoster();
}
