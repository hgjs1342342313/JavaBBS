package Services;

public interface ComFatory {
    void createComment();
}
